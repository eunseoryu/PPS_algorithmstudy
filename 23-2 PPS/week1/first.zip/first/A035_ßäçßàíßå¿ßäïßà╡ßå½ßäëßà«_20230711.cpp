#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int n;
    cin >> n;
    float num;
    char op;

    cin.ignore(); // Ignore the newline character after n

    for (int i = 0; i < n; i++) {
        cin >> num;
        cin.ignore(); // Ignore the space after num
        while (cin.get(op)) {
            if (op == '@')
                num *= 3;
            else if (op == '%')
                num += 5;
            else if (op == '#')
                num -= 7;
            else if (op == '\n')
                break;
        }
        cout << fixed << setprecision(2) << num << "\n";
    }

    return 0;
}