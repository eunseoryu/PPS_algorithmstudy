#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

int solution(const char* skill, const char* skill_trees[], size_t skill_trees_len) {
    int index = 0;
    int count = 0;
    bool flag = false;

    for (int i = 0; i < skill_trees_len; i++) {
        flag = false;
        index = 0;

        for (int j = 0; j < (int)strlen(skill_trees[i]); j++) {
            if (skill_trees[i][j] == skill[index])
                index++;
            else {
                for (int k = index + 1; k < (int)strlen(skill); k++) {
                    if (skill_trees[i][j] == skill[k]) {
                        flag = true;
                        count++;
                        break;
                    }
                }
            }

            if (flag)
                break;
        }
    }

    return skill_trees_len - count;
}