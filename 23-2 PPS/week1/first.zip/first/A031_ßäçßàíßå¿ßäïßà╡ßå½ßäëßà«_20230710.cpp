#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int n, m;

    cin >> n >> m;

    long long result = static_cast<long long>(n) * m - 1;

    cout << result;

    return 0;
}