#include <iostream>

using namespace std;

int main() {
    int n;
    int door;
    cin >> n;
    cin >> door;

    if (n > 5)
        cout << "Love is open door";
    else {
        for (int i = 1; i < n; i++) {
            door = 1 - door;
            cout << door << "\n";
        }
    }
}