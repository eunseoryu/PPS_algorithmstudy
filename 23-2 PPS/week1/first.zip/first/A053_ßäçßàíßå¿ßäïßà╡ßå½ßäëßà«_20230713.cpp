#include <iostream>
#include <stack>
#include <string>

using namespace std;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    stack<int> st;

    int n;
    string input;
    int num;

    cin >> n;

    for (int i = 0; i < n; i++) {
        cin >> input;

        if (input == "top") {
            if (st.empty())
                cout << -1 << "\n";
            else
                cout << st.top() << "\n";
        }
        else if (input == "size") {
            cout << st.size() << "\n";
        }
        else if (input == "empty") {
            if (st.empty())
                cout << 1 << "\n";
            else
                cout << 0 << "\n";
        }
        else if (input == "pop") {
            if (st.empty()) {
                cout << -1 << "\n";
            }
            else {
                cout << st.top() << "\n";
                st.pop();
            }
        }
        else {
            cin >> num;
            st.push(num);
        }
    }

    return 0;
}