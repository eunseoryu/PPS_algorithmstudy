#include <iostream>
using namespace std;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    string s;
    cin >> s;

    int length = s.length();
    for (int i = 0; i < length; i += 10) {
        cout << s.substr(i, 10) << endl;
    }

    return 0;
}