#include <vector>
using namespace std;

class Solution {
public:
  bool isPalindrome(ListNode* head) {
    vector<int> values;
    ListNode* current = head;

    while (current != nullptr) {
      values.push_back(current->val);
      current = current->next;
    }

    int size = values.size();
    for (int i = 0; i < size / 2; i++) {
      if (values[i] != values[size - i - 1])
        return false;
    }

    return true;
  }
};